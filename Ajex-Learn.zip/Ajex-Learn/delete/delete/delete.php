﻿<?php
include_once 'database.php';
mysqli_query($conn,"DELETE FROM myusers WHERE id='" . $_GET["id"] . "'");
header("Location:retrieve.php");
?> 


