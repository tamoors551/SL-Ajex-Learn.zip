<?php
// Including the database connection file
include_once 'database.php';

// Checking if the form is submitted
if(isset($_POST['save']))
{	 
	 // Retrieving دوباره حاصل کرنا form data
	 $first_name = $_POST['first_name'];
	 $last_name = $_POST['last_name'];
	 $city_name = $_POST['city_name'];
	 $email = $_POST['email'];
	 
	 // SQL query to insert data into the database
    //  Table name is employee , Coulume name is ()
	 $sql = "INSERT INTO employee (first_name,last_name,city_name,email)
	 VALUES ('$first_name','$last_name','$city_name','$email')";
	 
	 // Executing the SQL query
	 if (mysqli_query($conn, $sql)) {
		// If the query is successful, display success message
		echo "New record created successfully !";
	 } else {
		// If there is an error, display error message along with SQL query and error details
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 
	 // Closing the database connection
	 mysqli_close($conn);
}
?>
