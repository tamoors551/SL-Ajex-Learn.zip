CREATE TABLE `employee` (
	`userid` int(8) NOT NULL,
	`first_name` varchar(55) NOT NULL,
	`last_name` varchar(55) NOT NULL,
	`city_name` varchar(55) NOT NULL,
	`email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;