﻿<?php
// Including the database connection file
include_once 'database.php';

// Checking if the form submit button is clicked
if(isset($_POST['btn-save']))
{
    // Retrieving form input data
    $first_name = $_POST['first_name']; // Getting first name from the form
    $last_name = $_POST['last_name'];   // Getting last name from the form
    $city_name = $_POST['city_name'];   // Getting city name from the form
    $email = $_POST['email'];           // Getting email from the form
    
    // SQL query for inserting data into the 'myusers' table
    mysqli_query($conn, "INSERT INTO myusers (first_name, last_name, city_name, email) 
                        VALUES ('$first_name', '$last_name', '$city_name', '$email')")
    or die(mysqli_error()); // If there's an error in the query, terminate the script and display the MySQL error
    
    // Displaying a success message after data insertion
    echo "<p align=center>Data Added Successfully.</p>";
}
?>
