<?php
include_once 'database.php';

?>
<!DOCTYPE html>
<html>
<head>
<title> Retrive data</title>
</head>
<body>
<table>
    <thead>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>City</th>
            <th>Email id</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Initializing a variable to keep track of the row count
        $i = 0;
        $result = mysqli_query($conn,"SELECT * FROM myusers");
        // Looping through each row of the result set
        if(mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_array($result)) {
            
                $i++;

                ?>
                    <tr >
                        <td><?php echo $row["first_name"]; ?></td>
                        <td><?php echo $row["last_name"]; ?></td>
                        <td><?php echo $row["city_name"]; ?></td>
                        <td><?php echo $row["email"]; ?></td>
                    </tr>
                <?php
            }
        }

        ?>
    </tbody>


</table>
</body>
</html> 