<?php
// Including the database connection file
include_once 'database.php';

// Retrieving data from the 'myusers' table
$result = mysqli_query($conn,"SELECT * FROM myusers");

// Checking if there are any rows returned from the query
?>
<!DOCTYPE html>
<html>
 <head>
 <title> Retrive data</title>

 <!-- Including external CSS file -->
 <link rel="stylesheet" href="/css/style.css">
 
 <!-- Including Bootstrap CSS -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 </head>
<body>
<?php
// Checking if there are any rows returned from the query
if (mysqli_num_rows($result) > 0) {
?>
  <table class="table">
  
  <!-- Table header -->
  <tr>
    <td>First Name</td>
    <td>Last Name</td>
    <td>City</td>
    <td>Email id</td>
  </tr>
<?php
$i=0;
// Looping through each row of the result set
while($row = mysqli_fetch_array($result)) {
?>
<!-- Table rows displaying retrieved data -->
<tr>
    <td><?php echo $row["first_name"]; ?></td>
    <td><?php echo $row["last_name"]; ?></td>
    <td><?php echo $row["city_name"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
} else {
    // If no rows found in the result set, display a message
    echo "No result found";
}
?>
 </body>
</html>
