<?php
// Database connection parameters
$url = '127.0.0.1:3306'; // MySQL server address and port
$username = 'root'; // MySQL username
$password = ''; // MySQL password
$database = "crud"; // Database name

// Establishing a connection to the database
$conn = mysqli_connect($url, $username, $password, $database);

// Checking if the connection was successful
if (!$conn) {
    // If connection fails, display an error message and terminate script execution
    die('Could not Connect My Sql: ' .mysqli_error());
}
?>


<!-- mysqli_error() is a PHP function that returns a string description of the 
last error that occurred during the most recent MySQLi function call. 
In this context, it retrieves the error message associated with the failed connection attempt. -->